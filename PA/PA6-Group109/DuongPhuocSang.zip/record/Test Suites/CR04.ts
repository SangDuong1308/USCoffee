<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CR04</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5ba0f8a0-0e46-42fe-98df-d70f41253e29</testSuiteGuid>
   <testCaseLink>
      <guid>b78b7fa7-2ee6-4831-9497-7a058f9706f6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CR04</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>5f4d4959-8768-4d9e-a2ad-0667f11566b5</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/CR04data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>5f4d4959-8768-4d9e-a2ad-0667f11566b5</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>DescriptionCR04</value>
         <variableId>6c19df79-e0d2-4c13-b4c1-dac550b3f60b</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
