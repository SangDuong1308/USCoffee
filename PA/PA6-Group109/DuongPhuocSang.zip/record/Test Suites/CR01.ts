<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CR01</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>55163b4f-47cb-4a10-8701-ac07b7567fad</testSuiteGuid>
   <testCaseLink>
      <guid>aed3c496-e0f1-47d3-bcd2-07d9936832f9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CR01</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>0228051a-7e5a-4cef-af71-e69272d7ee5f</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/CR01data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>0228051a-7e5a-4cef-af71-e69272d7ee5f</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>DescriptionCR01</value>
         <variableId>43f8a546-56ce-449d-bd00-cb8d763a1eb0</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
