<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>AddP03</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>3dce65c4-c643-42c7-93c7-fa6d8d8c1098</testSuiteGuid>
   <testCaseLink>
      <guid>97d05924-1fb8-421b-9151-574c94adc32d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AddP03</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>eb96e444-d931-4f5c-8919-c8e51ff0552b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/AddP03Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>eb96e444-d931-4f5c-8919-c8e51ff0552b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>price</value>
         <variableId>549db30d-36fb-4b80-91cc-2790ec98016d</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
