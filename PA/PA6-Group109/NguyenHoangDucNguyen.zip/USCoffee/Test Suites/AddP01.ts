<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>AddP01</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>7d2ec7b1-d11d-4fdb-822a-5c866f9b841c</testSuiteGuid>
   <testCaseLink>
      <guid>ef3b33a8-e08f-46b3-a610-d14518ffe543</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/AddP01</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>d5c2e46f-73ec-4e0c-8d43-d63985a1488e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/AddP01Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>d5c2e46f-73ec-4e0c-8d43-d63985a1488e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>name</value>
         <variableId>451592c2-d43c-41ef-a9df-8486ec4095d5</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
