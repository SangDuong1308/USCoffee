<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>AP02</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>11b11f92-dd12-4bf5-ac18-82f6ab7f4575</testSuiteGuid>
   <testCaseLink>
      <guid>cc912bed-c6ed-4d43-98f2-3961dce77b10</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Ap02</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>f89b8910-3f23-4e68-9fc2-442876993cbf</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/AP02data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>f89b8910-3f23-4e68-9fc2-442876993cbf</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>DescriptionAP02</value>
         <variableId>0aee6fa7-5576-4705-89ad-10c4bd66f907</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
