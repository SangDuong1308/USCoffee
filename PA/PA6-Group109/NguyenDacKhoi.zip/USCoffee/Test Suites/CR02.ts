<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>CR02</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5ef426b1-6713-4893-a062-d2c241baac09</testSuiteGuid>
   <testCaseLink>
      <guid>6df04a6a-1f5e-4396-b797-8cde1cf8b83c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/CR02</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>0dd6f30f-1ad9-4637-9cc7-631e684da2ee</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/CR02</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>0dd6f30f-1ad9-4637-9cc7-631e684da2ee</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>CreateP02</value>
         <variableId>8d6c5ca1-11e7-48ce-b5f4-d6124cd8420a</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
